package Interfaz;

import javax.swing.*;
/*
public abstract class AbstractCamposPanel extends JPanel {

    protected AdministradorPaneles manager;
    protected CamposPanel camposPanel;
    //protected BotoneraPanel botonesPanel;

    public AbstractCamposPanel(AdministradorPaneles manager) {
        this.manager = manager;
        this.setCamposPanel();
        //this.setBotoneraPanel();
        armarPantallaPanel();
    }

    public void armarPantallaPanel() {
        //this.add(camposPanel);
        //this.add(botonesPanel);

        //tomar valores de los campos

        /*
        this.botonesPanel.getOkBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ejecutarAccionOk();
            }
        });

        this.botonesPanel.getCancelBtn().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ejecutarAccionCancel();
            }
        });*/

    //}

    /*private void setBotoneraPanel() {
        this.botonesPanel = new BotoneraPanel(this.manager);
    }*/

/*
    public abstract void setCamposPanel();

    public abstract void ejecutarAccionOk();
    public abstract void ejecutarAccionCancel();
}*/
